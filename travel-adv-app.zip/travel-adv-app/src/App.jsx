import Book from "./components/Book"


function App() {


  return (
    <>
        <Book/>
    </>
  )
}

export default App
